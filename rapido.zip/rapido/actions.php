<?php
session_start();
require_once 'connexion.php';

$action = $_POST['action'] ?? '';

function redirect($msg, $type = 'success') {
    $_SESSION['message'] = $msg;
    $_SESSION['message_type'] = $type;
    header('Location: index.php');
    exit;
}

// ─────────────────────────────────────────────────────
// Fonction : gérer l'upload d'une image de véhicule
// Retourne le nom du fichier sauvegardé, ou NULL
// ─────────────────────────────────────────────────────
function handleImageUpload(): ?string {
    // Pas de fichier envoyé ou champ vide → pas d'image
    if (empty($_FILES['image_vehicule']['name'])) {
        return null;
    }

    $file    = $_FILES['image_vehicule'];
    $maxSize = 2 * 1024 * 1024; // 2 Mo maximum

    // Vérifier qu'il n'y a pas eu d'erreur d'upload
    if ($file['error'] !== UPLOAD_ERR_OK) {
        redirect('Erreur lors de l\'upload de l\'image.', 'error');
    }

    // Vérifier la taille
    if ($file['size'] > $maxSize) {
        redirect('L\'image ne doit pas dépasser 2 Mo.', 'error');
    }

    // Vérifier le type MIME réel du fichier (sécurité)
    $allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mimeType, $allowedTypes)) {
        redirect('Format d\'image non autorisé. Utilisez JPG, PNG ou WEBP.', 'error');
    }

    // Générer un nom unique pour éviter les collisions
    // uniqid() = identifiant basé sur l'heure courante
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename  = 'vehicule_' . uniqid() . '.' . strtolower($extension);
    $uploadDir = __DIR__ . '/uploads/';
    $uploadPath = $uploadDir . $filename;

    // Déplacer le fichier depuis le dossier temporaire
    if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
        redirect('Impossible de sauvegarder l\'image.', 'error');
    }

    return $filename;
}

switch ($action) {

    // ─────────────────────────────────────────────────
    // AJOUTER UNE COURSE
    // ─────────────────────────────────────────────────
    case 'ajouter':
        $depart  = trim($_POST['point_depart']  ?? '');
        $arrivee = trim($_POST['point_arrivee'] ?? '');
        $date    = trim($_POST['date']           ?? '');
        $heure   = trim($_POST['heure']          ?? '');

        if (!$depart || !$arrivee || !$date || !$heure) {
            redirect('Tous les champs obligatoires doivent être remplis.', 'error');
        }

        $dateHeure     = $date . ' ' . $heure . ':00';
        $imageVehicule = handleImageUpload(); // NULL si pas d'image

        $stmt = $pdo->prepare("
            INSERT INTO courses
                (point_depart, point_arrivee, date_heure, image_vehicule, statut)
            VALUES
                (:depart, :arrivee, :date_heure, :image, 'en_attente')
        ");
        $stmt->execute([
            ':depart'     => $depart,
            ':arrivee'    => $arrivee,
            ':date_heure' => $dateHeure,
            ':image'      => $imageVehicule,
        ]);

        redirect('Course ajoutée avec succès !', 'success');
        break;

    // ─────────────────────────────────────────────────
    // AFFECTER UN CHAUFFEUR
    // ─────────────────────────────────────────────────
    case 'affecter':
        $courseId    = (int)($_POST['course_id']    ?? 0);
        $chauffeurId = (int)($_POST['chauffeur_id'] ?? 0);

        if (!$courseId || !$chauffeurId) {
            redirect('Données invalides.', 'error');
        }

        // Vérifier que la course est bien en attente
        $check = $pdo->prepare("SELECT statut FROM courses WHERE course_id = ?");
        $check->execute([$courseId]);
        $course = $check->fetch();

        if (!$course || $course['statut'] !== 'en_attente') {
            redirect('Cette course n\'est plus disponible.', 'error');
        }

        $stmt = $pdo->prepare("
            UPDATE courses
            SET chauffeur_id = :chauffeur_id,
                statut       = 'en_cours'
            WHERE course_id = :course_id
              AND statut     = 'en_attente'
        ");
        $stmt->execute([
            ':chauffeur_id' => $chauffeurId,
            ':course_id'    => $courseId,
        ]);

        redirect('Chauffeur affecté ! La course est maintenant en cours.', 'success');
        break;

    // ─────────────────────────────────────────────────
    // TERMINER UNE COURSE
    // ─────────────────────────────────────────────────
    case 'terminer':
        $courseId = (int)($_POST['course_id'] ?? 0);

        if (!$courseId) {
            redirect('ID de course invalide.', 'error');
        }

        $stmt = $pdo->prepare("
            UPDATE courses
            SET statut = 'terminee'
            WHERE course_id = :course_id
              AND statut     = 'en_cours'
        ");
        $stmt->execute([':course_id' => $courseId]);

        redirect('Course marquée comme terminée.', 'success');
        break;

    default:
        redirect('Action non reconnue.', 'error');
}
