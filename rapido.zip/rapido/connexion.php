<?php
// ============================================================
// connexion.php — Connexion PDO à PostgreSQL
// À inclure dans chaque fichier qui a besoin de la base
// ============================================================

require_once 'config.php';

try {
    $pdo = new PDO(
        "pgsql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME,
        DB_USER,
        DB_PASS,
        [
            // Lève une exception PHP en cas d'erreur SQL
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            // Les résultats sont retournés sous forme de tableaux associatifs
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            // Désactive l'émulation pour utiliser les vrais types PostgreSQL
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die('
        <div style="font-family:sans-serif; color:#DC2626; background:#FEF2F2;
                    border:2px solid #EF4444; border-radius:8px;
                    padding:20px; margin:40px auto; max-width:600px;">
            <strong>Erreur de connexion PostgreSQL</strong><br><br>
            ' . htmlspecialchars($e->getMessage()) . '<br><br>
            <em style="color:#6B7280;">
                Vérifie DB_PASS dans config.php et que PostgreSQL est bien démarré.
            </em>
        </div>
    ');
}
