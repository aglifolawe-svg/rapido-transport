<?php
session_start();
require_once 'connexion.php';

$stmt = $pdo->query("
    SELECT c.*,
           COALESCE(ch.prenoms || ' ' || ch.nom, NULL) AS chauffeur_nom
    FROM courses c
    LEFT JOIN chauffeurs ch ON c.chauffeur_id = ch.chauffeur_id
    ORDER BY c.date_heure DESC
");
$courses = $stmt->fetchAll();

$stmtChauf = $pdo->query("SELECT * FROM chauffeurs WHERE disponible = TRUE ORDER BY nom");
$chauffeurs = $stmtChauf->fetchAll();

$message     = $_SESSION['message']      ?? null;
$messageType = $_SESSION['message_type'] ?? 'success';
unset($_SESSION['message'], $_SESSION['message_type']);

$total     = count($courses);
$attente   = count(array_filter($courses, fn($c) => $c['statut'] === 'en_attente'));
$enCours   = count(array_filter($courses, fn($c) => $c['statut'] === 'en_cours'));
$terminees = count(array_filter($courses, fn($c) => $c['statut'] === 'terminee'));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RAPIDO — Gestion des Courses</title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <!-- Styles custom (minimum) -->
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg-light">

<!-- ══ NAVBAR ══════════════════════════════════════════════ -->
<nav class="navbar navbar-dark sticky-top rapido-navbar">
    <div class="container-xl">
        <a class="navbar-brand d-flex align-items-center gap-2" href="#">
            <span class="fs-3">🚖</span>
            <div>
                <div class="rapido-logo-title">RAPIDO</div>
                <div class="rapido-logo-sub">Transport Interurbain</div>
            </div>
        </a>
        <button class="btn btn-warning fw-bold" data-bs-toggle="modal" data-bs-target="#modalAdd">
            <i class="bi bi-plus-lg me-1"></i> Nouvelle Course
        </button>
    </div>
</nav>

<!-- ══ CONTENU ═════════════════════════════════════════════ -->
<div class="container-xl py-4">

    <!-- STATS -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="card rapido-stat-card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="rapido-stat-number text-warning"><?= $total ?></div>
                    <div class="rapido-stat-label">Total Courses</div>
                </div>
                <div class="rapido-stat-bar bg-warning"></div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card rapido-stat-card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="rapido-stat-number text-orange"><?= $attente ?></div>
                    <div class="rapido-stat-label">En attente</div>
                </div>
                <div class="rapido-stat-bar bg-orange"></div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card rapido-stat-card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="rapido-stat-number text-primary"><?= $enCours ?></div>
                    <div class="rapido-stat-label">En cours</div>
                </div>
                <div class="rapido-stat-bar bg-primary"></div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card rapido-stat-card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="rapido-stat-number text-success"><?= $terminees ?></div>
                    <div class="rapido-stat-label">Terminées</div>
                </div>
                <div class="rapido-stat-bar bg-success"></div>
            </div>
        </div>
    </div>

    <!-- TABLEAU -->
    <div class="card border-0 shadow-sm">
        <div class="card-header rapido-card-header d-flex align-items-center justify-content-between">
            <h5 class="mb-0 rapido-section-title">
                <i class="bi bi-list-ul me-2"></i>Liste des Courses
            </h5>
            <span class="badge bg-secondary"><?= $total ?> course<?= $total > 1 ? 's' : '' ?></span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="rapido-thead">
                        <tr>
                            <th>#ID</th>
                            <th>Véhicule</th>
                            <th>Départ</th>
                            <th>Arrivée</th>
                            <th>Date & Heure</th>
                            <th>Chauffeur</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($courses as $course): ?>
                        <tr>
                            <td><span class="fw-bold text-muted">#<?= $course['course_id'] ?></span></td>
                            <td>
                                <?php if (!empty($course['image_vehicule'])): ?>
                                    <img src="uploads/<?= htmlspecialchars($course['image_vehicule']) ?>"
                                         alt="Véhicule"
                                         class="rapido-thumb"
                                         data-bs-toggle="modal"
                                         data-bs-target="#modalImage"
                                         data-src="uploads/<?= htmlspecialchars($course['image_vehicule']) ?>"
                                         onclick="document.getElementById('modalImageSrc').src=this.dataset.src">
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <i class="bi bi-geo-alt text-muted me-1"></i>
                                <?= htmlspecialchars($course['point_depart']) ?>
                            </td>
                            <td>
                                <i class="bi bi-geo-alt-fill text-danger me-1"></i>
                                <?= htmlspecialchars($course['point_arrivee']) ?>
                            </td>
                            <td>
                                <i class="bi bi-calendar3 text-muted me-1"></i>
                                <?= date('d/m/Y H:i', strtotime($course['date_heure'])) ?>
                            </td>
                            <td>
                                <?php if (!empty($course['chauffeur_nom'])): ?>
                                    <i class="bi bi-person-fill text-muted me-1"></i>
                                    <?= htmlspecialchars($course['chauffeur_nom']) ?>
                                <?php else: ?>
                                    <span class="text-muted fst-italic small">Non assigné</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($course['statut'] === 'en_attente'): ?>
                                    <span class="badge rapido-badge-attente">
                                        <i class="bi bi-clock me-1"></i>En attente
                                    </span>
                                <?php elseif ($course['statut'] === 'en_cours'): ?>
                                    <span class="badge rapido-badge-encours">
                                        <i class="bi bi-arrow-repeat me-1"></i>En cours
                                    </span>
                                <?php else: ?>
                                    <span class="badge rapido-badge-terminee">
                                        <i class="bi bi-check-circle me-1"></i>Terminée
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($course['statut'] === 'en_attente'): ?>
                                    <button class="btn btn-sm btn-outline-dark"
                                        data-bs-toggle="modal"
                                        data-bs-target="#modalAssign"
                                        onclick="prepareAssign(<?= $course['course_id'] ?>, '<?= htmlspecialchars(addslashes($course['point_depart'])) ?> → <?= htmlspecialchars(addslashes($course['point_arrivee'])) ?>')">
                                        <i class="bi bi-person-check me-1"></i>Affecter
                                    </button>
                                <?php elseif ($course['statut'] === 'en_cours'): ?>
                                    <form method="POST" action="actions.php" class="d-inline">
                                        <input type="hidden" name="action" value="terminer">
                                        <input type="hidden" name="course_id" value="<?= $course['course_id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-success"
                                            onclick="return confirm('Marquer cette course comme terminée ?')">
                                            <i class="bi bi-check-lg me-1"></i>Terminer
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($courses)): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-5">
                                <i class="bi bi-inbox fs-2 d-block mb-2"></i>
                                Aucune course enregistrée
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div><!-- /container -->

<!-- ══ MODAL : Nouvelle course ════════════════════════════ -->
<div class="modal fade" id="modalAdd" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header rapido-modal-header">
                <h5 class="modal-title rapido-section-title">
                    <i class="bi bi-plus-circle me-2"></i>Nouvelle Course
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="actions.php" enctype="multipart/form-data">
                <input type="hidden" name="action" value="ajouter">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Point de départ *</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-geo-alt"></i></span>
                            <input type="text" class="form-control" name="point_depart" required
                                   placeholder="Ex: Cotonou - Gare Jonquet">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Point d'arrivée *</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-geo-alt-fill text-danger"></i></span>
                            <input type="text" class="form-control" name="point_arrivee" required
                                   placeholder="Ex: Parakou">
                        </div>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-7">
                            <label class="form-label fw-semibold">Date *</label>
                            <input type="date" class="form-control" name="date" required>
                        </div>
                        <div class="col-5">
                            <label class="form-label fw-semibold">Heure *</label>
                            <input type="time" class="form-control" name="heure" required>
                        </div>
                    </div>
                    <div class="mb-1">
                        <label class="form-label fw-semibold">Photo du véhicule</label>
                        <input type="file" class="form-control" name="image_vehicule"
                               accept="image/jpeg,image/png,image/webp">
                        <div class="form-text">JPG, PNG ou WEBP — max 2 Mo (optionnel)</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-warning fw-bold">
                        <i class="bi bi-check-lg me-1"></i>Enregistrer
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ══ MODAL : Affecter chauffeur ═════════════════════════ -->
<div class="modal fade" id="modalAssign" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header rapido-modal-header">
                <h5 class="modal-title rapido-section-title">
                    <i class="bi bi-person-check me-2"></i>Affecter un Chauffeur
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="actions.php">
                <input type="hidden" name="action" value="affecter">
                <input type="hidden" name="course_id" id="assignCourseId">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Course</label>
                        <input type="text" class="form-control bg-light" id="assignCourseLabel" readonly>
                    </div>
                    <div class="mb-1">
                        <label class="form-label fw-semibold">Chauffeur disponible *</label>
                        <select class="form-select" name="chauffeur_id" required>
                            <option value="">— Sélectionner un chauffeur —</option>
                            <?php foreach ($chauffeurs as $ch): ?>
                            <option value="<?= $ch['chauffeur_id'] ?>">
                                <?= $ch['sexe'] === 'M' ? 'M.' : 'Mme' ?>
                                <?= htmlspecialchars($ch['prenoms'] . ' ' . $ch['nom']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-warning fw-bold">
                        <i class="bi bi-person-check me-1"></i>Affecter
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ══ MODAL : Zoom image ═════════════════════════════════ -->
<div class="modal fade" id="modalImage" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-transparent border-0">
            <div class="modal-body text-center p-0">
                <img id="modalImageSrc" src="" alt="Véhicule"
                     class="img-fluid rounded shadow"
                     style="max-height:85vh; width:auto;">
            </div>
        </div>
    </div>
</div>

<!-- ══ TOAST ═══════════════════════════════════════════════ -->
<?php if ($message): ?>
<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index:9999">
    <div id="liveToast" class="toast show align-items-center border-0
        <?= $messageType === 'success' ? 'text-bg-dark' : 'text-bg-danger' ?>"
        role="alert">
        <div class="d-flex">
            <div class="toast-body fw-semibold">
                <i class="bi bi-<?= $messageType === 'success' ? 'check-circle' : 'exclamation-triangle' ?> me-2"></i>
                <?= htmlspecialchars($message) ?>
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto"
                    data-bs-dismiss="toast"></button>
        </div>
    </div>
</div>
<script>
    setTimeout(() => {
        const t = bootstrap.Toast.getInstance(document.getElementById('liveToast'));
        if(t) t.hide();
    }, 3500);
</script>
<?php endif; ?>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="app.js"></script>
</body>
</html>
