-- ============================================================
-- RAPIDO — Script SQL PostgreSQL (syntaxe correcte)
-- Données de test : contexte interurbain béninois
-- ============================================================

-- TABLE 1 : chauffeurs
-- SERIAL = équivalent PostgreSQL de AUTO_INCREMENT (MySQL)
-- CHECK(...) = équivalent PostgreSQL de ENUM (MySQL)
CREATE TABLE IF NOT EXISTS chauffeurs (
    chauffeur_id  SERIAL PRIMARY KEY,
    nom           VARCHAR(100) NOT NULL,
    prenoms       VARCHAR(150) NOT NULL,
    telephone     VARCHAR(20)  NOT NULL,
    sexe          CHAR(1)      NOT NULL CHECK (sexe IN ('M', 'F')),
    disponible    BOOLEAN      NOT NULL DEFAULT TRUE
);

-- TABLE 2 : courses
-- TIMESTAMP = équivalent PostgreSQL de DATETIME (MySQL)
CREATE TABLE IF NOT EXISTS courses (
    course_id     SERIAL PRIMARY KEY,
    point_depart  VARCHAR(200) NOT NULL,
    point_arrivee VARCHAR(200) NOT NULL,
    date_heure    TIMESTAMP    NOT NULL,
    chauffeur_id  INTEGER      DEFAULT NULL
                  REFERENCES chauffeurs(chauffeur_id) ON DELETE SET NULL,
    statut        VARCHAR(20)  NOT NULL DEFAULT 'en_attente'
                  CHECK (statut IN ('en_attente', 'en_cours', 'terminee'))
);

-- CHAUFFEURS : 2 chauffeurs béninois
INSERT INTO chauffeurs (nom, prenoms, telephone, sexe, disponible) VALUES
    ('AGOSSOU',  'Mathieu Kokou',  '+229 97 12 34 56', 'M', TRUE),
    ('DOSSOU',   'Célestine Aïda', '+229 96 78 90 11', 'F', TRUE);

-- COURSES DE TEST : trajets interurbains béninois réels
INSERT INTO courses (point_depart, point_arrivee, date_heure, chauffeur_id, statut) VALUES
    ('Cotonou - Gare Jonquet',    'Porto-Novo',      '2026-02-14 07:00:00', 1, 'terminee'),
    ('Cotonou - Gare de Dantokpa','Abomey-Calavi',   '2026-02-15 08:30:00', 1, 'terminee'),
    ('Porto-Novo',                'Bohicon',          '2026-02-16 09:00:00', 2, 'terminee'),
    ('Bohicon',                   'Parakou',          '2026-02-16 14:00:00', 2, 'en_cours'),
    ('Cotonou - Etoile Rouge',    'Natitingou',       '2026-02-17 06:00:00', NULL, 'en_attente'),
    ('Parakou',                   'Kandi',            '2026-02-17 10:00:00', NULL, 'en_attente'),
    ('Cotonou - Gare Jonquet',    'Ouidah',           '2026-02-17 15:30:00', NULL, 'en_attente');
