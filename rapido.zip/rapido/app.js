// Prépare le modal d'affectation avec les infos de la course
function prepareAssign(courseId, courseLabel) {
    document.getElementById('assignCourseId').value    = courseId;
    document.getElementById('assignCourseLabel').value = courseLabel;
}
