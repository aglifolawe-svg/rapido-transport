<?php
// ============================================================
// config.php — Paramètres de connexion à la base de données
// Modifie uniquement ce fichier si tu changes d'environnement
// ============================================================

define('DB_HOST', 'localhost');   // Serveur PostgreSQL
define('DB_PORT', '5432');        // Port par défaut PostgreSQL
define('DB_NAME', 'rapido');      // Nom de la base de données
define('DB_USER', 'postgres');    // Utilisateur PostgreSQL
define('DB_PASS', 'azerty');    // Ton mot de passe PostgreSQL
